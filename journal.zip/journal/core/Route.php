<?php
class Route
{public static function getPathArray()
{$BASE_URL = 'localhost:8081/journal/';$pathArray = [];
$currentPath = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

        if (strpos($currentPath, $BASE_URL) !== false) {
            $tmpPath = substr($currentPath, strlen($BASE_URL));
        } else {
            $tmpPath = '';
        }

        $tmpArray = explode("/", $tmpPath);

        // Фильтруем пустые значения
        $pathArray = array_values(array_filter($tmpArray, function($element) {
            return !empty($element);
        }));

        return $pathArray;
    }

    static function start()
    {
        // Контроллер и действие по умолчанию
        $controller_name = 'News';
        $action_name = 'index';

        $routes = self::getPathArray();

        // Получаем имя контроллера
        if (!empty($routes[0])) {
            $controller_name = $routes[0];
        }

        // Получаем имя действия
        if (!empty($routes[1])) {
            $action_name = $routes[1];
        }

        // Добавляем префиксы
        $model_name = 'Model_'.$controller_name;
        $controller_name = 'Controller_'.$controller_name;
        $action_name = 'action_'.$action_name;

        // Подключаем модель
        $model_file = strtolower($model_name).'.php';
        $model_path = "models/".$model_file;

        if (file_exists($model_path)) {
            include "models/".$model_file;
        }

        // Подключаем контроллер
        $controller_file = strtolower($controller_name).'.php';
        $controller_path = "controllers/".$controller_file;

        if (file_exists($controller_path)) {
            include "controllers/".$controller_file;
        }
        else {
            Route::ErrorPage404();
        }

        // Создаем контроллер
        $controller = new $controller_name;
        $action = $action_name;

        // Вызываем действие
        if (method_exists($controller, $action)) {
            $controller->$action();
        }
        else {
            Route::ErrorPage404();
        }
    }

    // Страница ошибки 404
    static function ErrorPage404()
    {
        $host = 'http://'.$_SERVER['HTTP_HOST'].'/journal/';

        header('HTTP/1.1 404 Not Found');
        header("Status: 404 Not Found");
        header('Location:'.$host.'404');
        exit;
    }
}
?>