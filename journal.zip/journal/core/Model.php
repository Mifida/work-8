
<?php
class Model
{
    function __construct() {
        // Подключаем БД
        $this->mysqli = mysqli_connect("db", "root", "mypassword", "POSTS");

        // Проверяем подключение
        if ($this->mysqli === false) {
            die("ERROR: Could not connect. " . mysqli_connect_error());
        }
    }

    // Выполняем SQL-запрос
    public function executeQuery($query) {
        $res = $this->mysqli->query($query);
        return $res;
    }

    function __destruct() {
        // Закрываем соединение
        $this->mysqli->close();
    }
}
?>
