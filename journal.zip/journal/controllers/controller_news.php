<?php

class Controller_News extends Controller
{
    function __construct()
    {
        // Создаем модель новостей
        $this->model = new Model_News();

        // Создаем представление
        $this->view = new View();
    }

    // Действие по умолчанию
    function action_index()
    {
        // Получаем данные от модели
        $data = $this->model->get_data();

        // Передаем данные в представление
        $this->view->generate('news_view.php', 'template_view.php', $data);
    }
}

?>