<?php

// Подключаем общие классы
require_once 'core/Model.php';
require_once 'core/View.php';
require_once 'core/Controller.php';

// Подключаем маршрутизатор
require_once 'core/Route.php';

// Запускаем маршрутизатор
Route::start();

?>