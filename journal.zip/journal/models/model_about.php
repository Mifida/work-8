
<?php

class Model_About extends Model
{
    public function get_data($id = -1)
    {
        // Если передан ID автора, выбираем одну запись
        if ($id != -1) {
            $result = $this->executeQuery(
                "SELECT * FROM authors WHERE id = ".$id
            );
        }
        else {
            // Если ID не передан, получаем всех авторов
            $result = $this->executeQuery(
                "SELECT * FROM authors"
            );
        }

        return $result;
    }
}

?>