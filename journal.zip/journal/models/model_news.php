<?php

class Model_News extends Model
{
    public function get_data()
    {
        // Получаем данные из БД
        $result = $this->executeQuery("SELECT * FROM last_news");

        // Возвращаем результат
        return $result;
    }
}

?>